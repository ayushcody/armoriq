"""
Policy evaluation engine.
Supports BLOCK_TOOL, REQUIRE_APPROVAL, VALIDATE_INPUT, BLOCK_KEYWORD rule types.
Includes built-in prompt injection detection.
"""

import fnmatch, uuid, json, logging, re
from datetime import datetime
from .models import PolicyRule
from .rule_store import RuleStore

logger = logging.getLogger(__name__)

# Always-on injection patterns (regardless of BLOCK_KEYWORD rules)
INJECTION_PATTERNS = [
    "ignore previous instructions",
    "ignore all rules",
    "you are now",
    "pretend you are",
    "disregard your",
    "override policy",
    "bypass guardrail",
    "forget your instructions",
    "act as if you have no",
    "jailbreak",
    "developer mode",
    "do anything now",
    "dan mode",
]


class PolicyEngine:
    def __init__(self, store: RuleStore):
        self._store = store
        self._rules: list[PolicyRule] = store.load_all()
        self._approvals: dict[str, str] = {}  # approval_id -> "pending"|"approved"|"denied"
        store.on_change(self._on_rules_changed)
        logger.info(f"PolicyEngine initialized with {len(self._rules)} rules")

    def _on_rules_changed(self):
        """Called by RuleStore watcher thread when rules change in DB."""
        self._rules = self._store.load_all()
        logger.info(f"PolicyEngine: hot-reloaded {len(self._rules)} rules")

    def evaluate(self, tool_call: dict) -> dict:
        """
        Called by agent_loop for every tool call before execution.
        Priority: BLOCK_KEYWORD (always) > BLOCK_TOOL > REQUIRE_APPROVAL > VALIDATE_INPUT
        Returns dict with keys: action, reason?, rule_id?, approval_id?, timeout?
        """
        name = tool_call["name"]
        args = tool_call["args"]
        args_str = json.dumps(args).lower()
        enabled = [r for r in self._rules if r.enabled]

        # 1. Always check for prompt injection (built-in, no rule needed)
        for pattern in INJECTION_PATTERNS:
            if pattern in args_str:
                return {
                    "action": "BLOCK",
                    "reason": f"Prompt injection pattern detected: '{pattern}'",
                    "rule_id": "builtin:injection_guard"
                }

        # 2. BLOCK_KEYWORD rules (custom keywords from admin)
        for rule in enabled:
            if rule.type != "BLOCK_KEYWORD":
                continue
            keywords = [k.lower() for k in rule.config.get("keywords", [])]
            mode = rule.config.get("match_mode", "any")
            matched = [k for k in keywords if k in args_str]
            if (mode == "any" and matched) or (mode == "all" and len(matched) == len(keywords)):
                return {
                    "action": "BLOCK",
                    "reason": f"Blocked keyword matched in tool arguments",
                    "rule_id": rule.id
                }

        # 3. BLOCK_TOOL (supports glob patterns e.g. "trigger_*", "scale_*")
        for rule in enabled:
            if rule.type != "BLOCK_TOOL":
                continue
            pattern = rule.config.get("tool_name", "")
            if fnmatch.fnmatch(name, pattern):
                return {
                    "action": "BLOCK",
                    "reason": f"Tool '{name}' is blocked by rule '{rule.name}'",
                    "rule_id": rule.id
                }

        # 4. REQUIRE_APPROVAL
        for rule in enabled:
            if rule.type != "REQUIRE_APPROVAL":
                continue
            pattern = rule.config.get("tool_name", "")
            if fnmatch.fnmatch(name, pattern):
                approval_id = str(uuid.uuid4())
                self._approvals[approval_id] = "pending"
                return {
                    "action": "REQUIRE_APPROVAL",
                    "rule_id": rule.id,
                    "approval_id": approval_id,
                    "timeout": rule.config.get("approval_timeout_seconds", 300)
                }

        # 5. VALIDATE_INPUT
        for rule in enabled:
            if rule.type != "VALIDATE_INPUT":
                continue
            pattern = rule.config.get("tool_name", "")
            if not fnmatch.fnmatch(name, pattern):
                continue
            violation = self._check_validation(args, rule.config)
            if violation:
                return {
                    "action": "BLOCK",
                    "reason": violation,
                    "rule_id": rule.id
                }

        return {"action": "ALLOW"}

    def _check_validation(self, args: dict, config: dict) -> str | None:
        field = config.get("field_path")
        rule_str = config.get("rule", "")
        value = args.get(field)
        if value is None:
            return None
        if rule_str.startswith("max_value:"):
            limit = int(rule_str.split(":")[1])
            if isinstance(value, (int, float)) and value > limit:
                return f"Field '{field}' value {value} exceeds maximum allowed {limit}"
        elif rule_str.startswith("allowlist:"):
            allowed = json.loads(rule_str.split(":", 1)[1])
            if value not in allowed:
                return f"Field '{field}' value '{value}' not in allowlist: {allowed}"
        elif rule_str.startswith("regex:"):
            pattern = rule_str.split(":", 1)[1]
            if not re.match(pattern, str(value)):
                return f"Field '{field}' value '{value}' does not match required pattern"
        return None

    # --- Approval management ---
    def get_approval_status(self, approval_id: str) -> str:
        return self._approvals.get(approval_id, "unknown")

    def resolve_approval(self, approval_id: str, decision: str):
        if approval_id in self._approvals:
            self._approvals[approval_id] = decision

    def expire_approval(self, approval_id: str):
        self._approvals[approval_id] = "denied"

    def get_pending_approvals(self) -> list[dict]:
        return [
            {"approval_id": k, "status": v}
            for k, v in self._approvals.items()
            if v == "pending"
        ]

    # --- CRUD (called by dashboard API, persisted via rule_store) ---
    def create_rule(self, rule: PolicyRule) -> PolicyRule:
        self._store.save(rule)
        return rule

    def update_rule(self, rule: PolicyRule) -> PolicyRule:
        rule.updated_at = datetime.utcnow().isoformat()
        self._store.save(rule)
        return rule

    def delete_rule(self, rule_id: str):
        self._store.delete(rule_id)

    def toggle_rule(self, rule_id: str, enabled: bool) -> PolicyRule | None:
        rule = next((r for r in self._rules if r.id == rule_id), None)
        if rule:
            rule.enabled = enabled
            rule.updated_at = datetime.utcnow().isoformat()
            self._store.save(rule)
        return rule

    def list_rules(self) -> list[PolicyRule]:
        return list(self._rules)
