# Guarded AI Agent with MCP Support

A full-stack AI agent system with real-time policy guardrails, MCP tool integration, and an admin dashboard.

## Architecture

```
┌──────────────┐     ┌──────────────┐     ┌───────────────────┐
│   Dashboard  │────▶│  FastAPI      │────▶│  Policy Engine    │
│   (React)    │◀────│  Agent API    │◀────│  (SQLite-backed)  │
│   :5173      │     │  :8000        │     └───────────────────┘
└──────────────┘     │               │
                     │  ┌──────────┐ │     ┌───────────────────┐
                     │  │ Agent    │ │────▶│  MCP Servers       │
                     │  │ Loop     │ │◀────│  (stdio + SSE)     │
                     │  └──────────┘ │     └───────────────────┘
                     │               │
                     │  ┌──────────┐ │     ┌───────────────────┐
                     │  │LLM Client│─│────▶│ LM Studio / Groq  │
                     │  └──────────┘ │     └───────────────────┘
                     └──────────────┘
```

## Components

- **AI Agent** — FastAPI backend with a proper LLM tool-use loop
- **Policy Engine** — Standalone module for guardrail rules (BLOCK_TOOL, REQUIRE_APPROVAL, VALIDATE_INPUT, BLOCK_KEYWORD)
- **Custom MCP Server** — "DevOps Sentinel" with 5 infrastructure tools
- **Dashboard** — React (Vite) admin UI for rules, logs, approvals, and stats

## Quick Start

### 1. Setup
```bash
cd guarded-agent
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your GROQ_API_KEY
```

### 2. Start the Agent
```bash
cd agent && uvicorn main:app --reload --port 8000
```

### 3. Start the Dashboard
```bash
cd dashboard && npm install && npm run dev
```

### 4. Verify
```bash
curl http://localhost:8000/api/health
```

## LLM Strategy

- **Primary:** LM Studio (local, OpenAI-compatible)
- **Fallback:** Groq API (automatic failover)

## Policy Rule Types

| Type | Description |
|------|-------------|
| BLOCK_TOOL | Block specific tools (supports glob patterns) |
| REQUIRE_APPROVAL | Require admin approval before execution |
| VALIDATE_INPUT | Validate tool arguments against rules |
| BLOCK_KEYWORD | Block requests containing specific keywords |

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/chat | Send message to agent |
| GET | /api/health | Health check |
| GET/POST | /api/rules | List/create rules |
| PATCH | /api/rules/:id/toggle | Toggle rule |
| GET | /api/logs | Query tool call logs |
| GET | /api/approvals | List pending approvals |
| WS | /ws/logs | Real-time log stream |

## Docker

```bash
docker-compose up --build
```
